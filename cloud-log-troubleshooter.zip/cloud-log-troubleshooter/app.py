
from pathlib import Path

from flask import Flask, jsonify, render_template, request

from log_analyzer import analyze, parse_logs
from log_analyzer.llm import PROVIDERS, ai_analysis, build_prompt, chat as ai_chat

app = Flask(__name__)
SAMPLE = Path(__file__).parent / "sample_logs" / "app.log"
EXCERPT_CHARS = 12000


def log_excerpt(text: str, limit: int = EXCERPT_CHARS) -> str:
    """Keep the start and end of long logs so the chat context stays small."""
    if len(text) <= limit:
        return text
    half = limit // 2
    return text[:half] + "\n...[log truncated]...\n" + text[-half:]


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    try:
        reply = ai_chat(
            context=str(data.get("context", "")),
            messages=data.get("messages", []),
            api_key=str(data.get("api_key", "")).strip(),
            provider=str(data.get("provider", "")).strip(),
            model=str(data.get("model", "")).strip(),
            base_url=str(data.get("base_url", "")).strip(),
        )
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    except Exception as exc:
        return jsonify(error=f"Assistant unavailable: {exc}"), 502
    return jsonify(reply=reply)


@app.route("/", methods=["GET", "POST"])
def index():
    report, ai, error, text = None, None, None, ""
    source = request.form.get("source", "sample")

    if request.method == "POST":
        if source == "sample":
            text = SAMPLE.read_text(encoding="utf-8")
        elif source == "upload":
            f = request.files.get("file")
            if f and f.filename:
                text = f.read().decode("utf-8", errors="replace")
        else:
            text = request.form.get("text", "")

        if text.strip():
            report = analyze(parse_logs(text))
            if request.form.get("use_ai"):
                try:
                    ai = ai_analysis(
                        report,
                        api_key=request.form.get("api_key", "").strip(),
                        provider=request.form.get("provider", "").strip(),
                        model=request.form.get("model", "").strip(),
                        base_url=request.form.get("base_url", "").strip(),
                    )
                except Exception as exc:
                    error = f"AI explanation unavailable: {exc}"
        else:
            error = "No logs provided. Choose the sample, upload a file, or paste text."

    chat_context = ""
    if report:
        chat_context = build_prompt(report, max_issues=15)
        if ai:
            chat_context += "\n\nEarlier AI explanation:\n" + ai
        chat_context += "\n\nLog excerpt:\n" + log_excerpt(text)

    peak = max(report.timeline.values()) if report and report.timeline else 1
    return render_template("index.html", report=report, ai=ai, error=error,
                           peak=peak, source=source, providers=PROVIDERS, form=request.form, chat_context=chat_context, pasted=text if source == "paste" else "")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8501, debug=False)
