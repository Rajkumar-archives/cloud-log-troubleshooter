import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from log_analyzer import analyze, parse_logs, signature  # noqa: E402

SAMPLE = """2026-10-07 10:00:01,120 INFO [api] ok
2026-10-07 10:02:41,882 ERROR [svc] Timeout while connecting to db:5432 after 30000ms
    at Pool.acquire(Pool.java:88)
2026-10-07 10:02:55,101 ERROR [svc] Timeout while connecting to db:5432 after 31000ms
2026-10-07 10:03:05,014 ERROR [gw] Upstream svc returned 503
"""


def test_parse_levels_and_details():
    entries = parse_logs(SAMPLE)
    assert [e.level for e in entries] == ["INFO", "ERROR", "ERROR", "ERROR"]
    assert entries[1].details == ["at Pool.acquire(Pool.java:88)"]
    assert entries[1].timestamp is not None


def test_signature_groups_numbers():
    assert signature("Timeout after 30000ms on 10.0.0.1:80") == signature("Timeout after 5ms on 10.0.0.9:80")


def test_analyze_groups_and_root_cause():
    r = analyze(parse_logs(SAMPLE))
    assert r.total == 4
    timeout = [i for i in r.issues if "Timeout" in i.example][0]
    assert timeout.count == 2 and timeout.category.startswith("Networking")
    assert r.root_cause is timeout
    assert r.error_rate == 75.0


def test_no_errors():
    r = analyze(parse_logs("2026-10-07 10:00:01 INFO all good"))
    assert r.root_cause is None and r.issues == []


def test_web_app_renders_sample():
    from app import app
    client = app.test_client()
    assert client.get("/").status_code == 200
    resp = client.post("/", data={"source": "sample"})
    body = resp.get_data(as_text=True)
    assert resp.status_code == 200
    assert "Likely trigger" in body and "Grouped issues" in body


def test_detect_provider_from_key(monkeypatch):
    from log_analyzer.llm import detect_provider
    for var in ("LLM_PROVIDER",):
        monkeypatch.delenv(var, raising=False)
    assert detect_provider("sk-ant-abc") == "anthropic"
    assert detect_provider("sk-or-abc") == "openrouter"
    assert detect_provider("AIzaXYZ") == "gemini"
    assert detect_provider("gsk_abc") == "groq"
    assert detect_provider("sk-abc") == "openai"


def test_ai_analysis_request_shapes(monkeypatch):
    from log_analyzer import llm
    report = analyze(parse_logs(SAMPLE))
    calls = []

    def fake_post(url, headers, payload, timeout=60):
        calls.append((url, headers, payload))
        if "anthropic" in url:
            return {"content": [{"type": "text", "text": "claude-ok"}]}
        if "googleapis" in url:
            return {"candidates": [{"content": {"parts": [{"text": "gemini-ok"}]}}]}
        return {"choices": [{"message": {"content": "openai-ok"}}]}

    monkeypatch.setattr(llm, "_post", fake_post)
    assert llm.ai_analysis(report, api_key="k", provider="anthropic") == "claude-ok"
    assert calls[-1][1]["x-api-key"] == "k"
    assert llm.ai_analysis(report, api_key="k", provider="gemini") == "gemini-ok"
    assert calls[-1][0].endswith("gemini-2.0-flash:generateContent")
    assert llm.ai_analysis(report, api_key="k", provider="groq") == "openai-ok"
    assert calls[-1][1]["Authorization"] == "Bearer k"
    # local server needs no key; custom needs base URL + model
    assert llm.ai_analysis(report, provider="ollama") == "openai-ok"
    assert "Authorization" not in calls[-1][1]
    assert llm.ai_analysis(report, provider="custom", base_url="http://h/v1", model="m") == "openai-ok"
    assert calls[-1][0] == "http://h/v1/chat/completions"


def test_missing_key_is_clear_error(monkeypatch):
    import pytest
    from log_analyzer import llm
    for v in ("LLM_API_KEY", "LLM_PROVIDER", "OPENAI_API_KEY"):
        monkeypatch.delenv(v, raising=False)
    with pytest.raises(RuntimeError, match="No API key"):
        llm.ai_analysis(analyze(parse_logs(SAMPLE)), provider="openai")


def test_chat_multi_turn_shapes(monkeypatch):
    import pytest
    from log_analyzer import llm
    seen = []

    def fake_post(url, headers, payload, timeout=60):
        seen.append((url, payload))
        if "anthropic" in url:
            return {"content": [{"type": "text", "text": "a"}]}
        if "googleapis" in url:
            return {"candidates": [{"content": {"parts": [{"text": "g"}]}}]}
        return {"choices": [{"message": {"content": "o"}}]}

    monkeypatch.setattr(llm, "_post", fake_post)
    msgs = [{"role": "assistant", "content": "stray"},          # leading assistant turn is dropped
            {"role": "user", "content": "why?"},
            {"role": "assistant", "content": "because"},
            {"role": "user", "content": "how to fix?"}]
    assert llm.chat("CTX", msgs, api_key="k", provider="anthropic") == "a"
    p = seen[-1][1]
    assert [m["role"] for m in p["messages"]] == ["user", "assistant", "user"] and "CTX" in p["system"]
    assert llm.chat("CTX", msgs, api_key="k", provider="gemini") == "g"
    assert [c["role"] for c in seen[-1][1]["contents"]] == ["user", "model", "user"]
    assert llm.chat("CTX", msgs, api_key="k", provider="openai") == "o"
    assert seen[-1][1]["messages"][0]["role"] == "system"
    with pytest.raises(ValueError):
        llm.chat("CTX", [{"role": "assistant", "content": "x"}], api_key="k", provider="openai")


def test_chat_endpoint_and_page_context(monkeypatch):
    from app import app
    from log_analyzer import llm
    monkeypatch.setattr(llm, "_post", lambda *a, **k: {"choices": [{"message": {"content": "hello"}}]})
    c = app.test_client()
    ok = c.post("/chat", json={"context": "x", "provider": "openai", "api_key": "k",
                               "messages": [{"role": "user", "content": "hi"}]})
    assert ok.status_code == 200 and ok.get_json()["reply"] == "hello"
    assert c.post("/chat", json={"messages": []}).status_code == 400
    page = c.post("/", data={"source": "sample"}).get_data(as_text=True)
    assert "Ask the debugging assistant" in page and "Log excerpt:" in page
