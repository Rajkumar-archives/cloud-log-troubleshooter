
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

TS_RE = re.compile(
    r"^\[?(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2})(?:[.,]\d+)?(?:Z|[+-]\d{2}:?\d{2})?\]?"
)
LEVEL_RE = re.compile(r"\b(DEBUG|INFO|WARN(?:ING)?|ERROR|ERR|CRITICAL|FATAL|SEVERE)\b")
ERRORISH_RE = re.compile(r"exception|traceback|failed|panic|segfault", re.I)
NORMALIZE = {"WARNING": "WARN", "ERR": "ERROR", "FATAL": "CRITICAL", "SEVERE": "ERROR"}


@dataclass
class LogEntry:
    line_no: int
    level: str
    message: str
    timestamp: Optional[datetime] = None
    details: List[str] = field(default_factory=list)  # stack-trace / continuation lines


def _parse_ts(raw: str) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(raw.replace(" ", "T"))
    except ValueError:
        return None


def parse_logs(text: str) -> List[LogEntry]:
    entries: List[LogEntry] = []
    for i, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue
        ts_match = TS_RE.match(line)
        rest = line[ts_match.end():].strip() if ts_match else line.strip()
        level_match = LEVEL_RE.search(rest[:80])

        
        is_continuation = (
            not ts_match
            and not level_match
            and entries
            and (line[0].isspace() or rest.startswith(("at ", "Caused by", "Traceback", "File ")))
        )
        if is_continuation:
            entries[-1].details.append(line.strip())
            continue

        if level_match:
            level = NORMALIZE.get(level_match.group(1), level_match.group(1))
            message = rest[level_match.end():].strip(" -:") or rest
        else:
            level = "ERROR" if ERRORISH_RE.search(rest) else "INFO"
            message = rest

        entries.append(
            LogEntry(
                line_no=i,
                level=level,
                message=message,
                timestamp=_parse_ts(ts_match.group(1)) if ts_match else None,
            )
        )
    return entries
