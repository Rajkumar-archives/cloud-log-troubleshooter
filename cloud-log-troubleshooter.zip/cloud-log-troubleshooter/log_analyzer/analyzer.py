
import re
from collections import Counter, OrderedDict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional

from .parser import LogEntry

KNOWLEDGE_BASE = [
    (r"pool (exhausted|usage)|too many connections|max_connections", "Resource Exhaustion",
     "Database/connection pool is saturated, so new requests wait or fail.",
     "Increase pool size or max_connections, fix connection leaks, add pooling proxy (e.g. PgBouncer/RDS Proxy)."),
    (r"CrashLoopBackOff|ImagePullBackOff|ErrImagePull", "Container / Kubernetes",
     "Container keeps crashing or its image cannot be pulled.",
     "Run `kubectl describe pod` and `kubectl logs --previous`; check image name/tag, registry credentials, and startup errors."),
    (r"out ?of ?memory|OOMKilled|heap space", "Memory",
     "Process exceeded its memory limit and was killed or crashed.",
     "Raise memory limits, look for leaks, tune heap size, and add memory alerts."),
    (r"no space left|disk (usage|full)", "Disk",
     "Disk or volume is full.",
     "Clean logs/temp files, enable log rotation, expand the volume, add disk usage alerts."),
    (r"deadlock", "Database",
     "Concurrent transactions are locking each other.",
     "Keep transactions short, acquire locks in a consistent order, add retry logic."),
    (r"could not resolve|name or service not known|NXDOMAIN|\bdns\b", "Networking / DNS",
     "Hostname cannot be resolved.",
     "Check DNS config, service names, VPC DNS settings, and security groups."),
    (r"\bssl\b|certificate|tls handshake", "Security / TLS",
     "TLS certificate is expired, untrusted, or mismatched.",
     "Renew/replace the certificate and verify the trust chain and hostname."),
    (r"throttl|rate (limit|exceeded)|\b429\b|too many requests", "Rate Limiting",
     "Requests are exceeding an API or service quota.",
     "Add exponential backoff + jitter, cache results, or request a quota increase."),
    (r"connection refused|ECONNREFUSED", "Networking",
     "Target service is down, not listening, or blocked by a firewall.",
     "Check the service is running and listening on the port, and review security groups / network policies."),
    (r"timed? ?out|timeout", "Networking / Latency",
     "Downstream service or network is too slow or unreachable.",
     "Check downstream health, network path, and timeout/retry settings; add circuit breakers."),
    (r"permission denied|access ?denied|forbidden|\b403\b", "Permissions (IAM)",
     "Identity lacks the required permission.",
     "Review IAM roles/policies and resource ACLs; grant least-privilege access needed."),
    (r"unauthori[sz]ed|invalid (token|credentials)|authentication failed|\b401\b", "Authentication",
     "Credentials or token are missing, invalid, or expired.",
     "Rotate/refresh credentials and verify the secret or token is being passed correctly."),
    (r"\b50[0234]\b|bad gateway|service unavailable|upstream", "Upstream Failure",
     "A backend service is failing, so the gateway returns 5xx.",
     "Find the failing upstream service (usually the earliest error) and fix that first."),
    (r"not found|no such file|FileNotFoundError|ENOENT|\b404\b", "Missing Resource",
     "A file, route, or object being requested does not exist.",
     "Verify paths, bucket/object names, deployments, and routing config."),
]
_COMPILED = [(re.compile(p, re.I), c, cause, fix) for p, c, cause, fix in KNOWLEDGE_BASE]

_UUID = re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I)
_IP = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?\b")
_HEX = re.compile(r"0x[0-9a-fA-F]+")
_NUM = re.compile(r"(?<![A-Za-z_])\d+(?:\.\d+)?")


def signature(message: str) -> str:
    """Replace variable parts (ids, IPs, numbers) so repeated errors group together."""
    s = _UUID.sub("<uuid>", message)
    s = _IP.sub("<ip>", s)
    s = _HEX.sub("<hex>", s)
    s = _NUM.sub("<n>", s)
    return re.sub(r"\s+", " ", s).strip()


def classify(text: str):
    for rx, category, cause, fix in _COMPILED:
        if rx.search(text):
            return category, cause, fix
    return ("Uncategorized", "No known pattern matched. Inspect the surrounding log lines.",
            "Check the stack trace and the events just before the first occurrence.")


@dataclass
class Issue:
    signature: str
    level: str
    count: int
    first_line: int
    first_seen: Optional[datetime]
    last_seen: Optional[datetime]
    example: str
    category: str
    cause: str
    fix: str
    details: List[str] = field(default_factory=list)


@dataclass
class Report:
    total: int
    level_counts: Dict[str, int]
    start: Optional[datetime]
    end: Optional[datetime]
    issues: List[Issue]
    root_cause: Optional[Issue]
    timeline: Dict[str, int]  

    @property
    def error_rate(self) -> float:
        errors = self.level_counts.get("ERROR", 0) + self.level_counts.get("CRITICAL", 0)
        return round(100 * errors / self.total, 1) if self.total else 0.0


_SEVERITY = {"CRITICAL": 0, "ERROR": 1, "WARN": 2}


def analyze(entries: List[LogEntry]) -> Report:
    levels = Counter(e.level for e in entries)
    stamps = [e.timestamp for e in entries if e.timestamp]

    groups: "OrderedDict[tuple, Issue]" = OrderedDict()
    timeline: Counter = Counter()
    for e in entries:
        if e.level not in _SEVERITY:
            continue
        key = (e.level, signature(e.message))
        if key not in groups:
            category, cause, fix = classify(e.message + " " + " ".join(e.details))
            groups[key] = Issue(key[1], e.level, 0, e.line_no, e.timestamp, e.timestamp,
                                e.message, category, cause, fix, list(e.details))
        issue = groups[key]
        issue.count += 1
        if e.timestamp:
            issue.last_seen = e.timestamp
        if e.level in ("ERROR", "CRITICAL") and e.timestamp:
            timeline[e.timestamp.strftime("%Y-%m-%d %H:%M")] += 1

    issues = sorted(groups.values(), key=lambda i: (_SEVERITY[i.level], -i.count))

    errors = [i for i in issues if i.level in ("ERROR", "CRITICAL")]
    root = min(errors, key=lambda i: (i.first_line, -i.count)) if errors else None

    return Report(len(entries), dict(levels), min(stamps, default=None), max(stamps, default=None),
                  issues, root, dict(sorted(timeline.items())))
